/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Admin
 */
public class SanPham {

    private int stt;
    private String ten, loai, kt, ms, cl;
    private double gia;
    private int sl;

    public SanPham() {
    }

    public SanPham(int stt, String ten, String loai, String kt, String ms, String cl, double gia, int sl) {
        this.stt = stt;
        this.ten = ten;
        this.loai = loai;
        this.kt = kt;
        this.ms = ms;
        this.cl = cl;
        this.gia = gia;
        this.sl = sl;
    }

    public int getStt() {
        return stt;
    }

    public void setStt(int stt) {
        this.stt = stt;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public String getKt() {
        return kt;
    }

    public void setKt(String kt) {
        this.kt = kt;
    }

    public String getMs() {
        return ms;
    }

    public void setMs(String ms) {
        this.ms = ms;
    }

    public String getCl() {
        return cl;
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public double getGia() {
        return gia;
    }

    public void setGia(double gia) {
        this.gia = gia;
    }

    public int getSl() {
        return sl;
    }

    public void setSl(int sl) {
        this.sl = sl;
    }

    
    

    @Override
    public String toString() {
        return "SanPham{" + "stt=" + stt + ", ten=" + ten + ", loai=" + loai + ", kt=" + kt + ", ms=" + ms + ", cl=" + cl + ", gia=" + gia + ", sl=" + sl + '}';
    }

    public Object[] toDataRow(){
        return new Object[]{this.stt, this.ten, this.loai, this.kt, this.ms, this.cl, this.gia, this.sl};
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import java.awt.Color;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.ChatLieu;
import model.KichThuoc;
import model.LoaiSanPham;
import model.MauSac;
import model.SanPham;
import service.SanPhamService;

/**
 *
 * @author Admin
 */
public class QuanLySanPham extends javax.swing.JFrame {

    DefaultTableModel model = new DefaultTableModel();
    SanPhamService service = new SanPhamService();
    int index;

    public QuanLySanPham() {
        initComponents();
        setLocationRelativeTo(null);

        fillCbo();
        fillToTableSanPham(service.getAllSP());

        showDataSP(index);

        jpTrangChu.setVisible(true);
        jpThongKe.setVisible(false);
        jpSanPham.setVisible(false);
        jpNhanVien.setVisible(false);
        jpHoaDon.setVisible(false);
        jpKhachHang.setVisible(false);
        jpLichSu.setVisible(false);
        jpKhuyenMai.setVisible(false);
        jpDoiMatKhau.setVisible(false);
    }

    public void fillCbo() {
        cboMau.removeAllItems();
        List<MauSac> listMau = service.getAllMau();
        for (MauSac mauSac : listMau) {
            cboMau.addItem(mauSac.getTenMau());
        }

        cboKichThuoc.removeAllItems();
        List<KichThuoc> listKT = service.getAllKT();
        for (KichThuoc kichThuoc : listKT) {
            cboKichThuoc.addItem(kichThuoc.getTenKichThuoc());
        }

        cboChatLieu.removeAllItems();
        List<ChatLieu> listCL = service.getAllCL();
        for (ChatLieu chatLieu : listCL) {
            cboChatLieu.addItem(chatLieu.getTenChatLieu());
        }

        cboLoaiSP.removeAllItems();
        List<LoaiSanPham> listLoai = service.getAllLSP();
        for (LoaiSanPham loaiSanPham : listLoai) {
            cboLoaiSP.addItem(loaiSanPham.getTenSP());
        }
    }

    public void fillToTableSanPham(List<SanPham> list) {
        model.setRowCount(0);
        model = (DefaultTableModel) tblSanPham.getModel();
        for (SanPham sanPham : list) {
            model.addRow(sanPham.toDataRow());
        }
    }

    public void fillToTableMau(List<MauSac> list) {
        model.setRowCount(0);
        model = (DefaultTableModel) tblThuocTinh.getModel();
        for (MauSac mauSac : list) {
            model.addRow(mauSac.toDataRow());
        }
    }

    public void fillToTableKichThuoc(List<KichThuoc> list) {
        model.setRowCount(0);
        model = (DefaultTableModel) tblThuocTinh.getModel();
        for (KichThuoc kichThuoc : list) {
            model.addRow(kichThuoc.toDataRow());
        }
    }

    public void fillToTableChatLieu(List<ChatLieu> list) {
        model.setRowCount(0);
        model = (DefaultTableModel) tblThuocTinh.getModel();
        for (ChatLieu chatLieu : list) {
            model.addRow(chatLieu.toDataRow());
        }
    }

    public void fillToTableLoaiSP(List<LoaiSanPham> list) {
        model.setRowCount(0);
        model = (DefaultTableModel) tblThuocTinh.getModel();
        for (LoaiSanPham loaiSanPham : list) {
            model.addRow(loaiSanPham.toDataRow());
        }

    }

    public void showDataMau(int index) {
        MauSac ms = service.getAllMau().get(index);
        txtMaThuocTinh.setText(ms.getMaMau());
        txtTenThuocTinh.setText(ms.getTenMau());
    }

    public void showDataKichThuoc(int index) {
        KichThuoc kt = service.getAllKT().get(index);
        txtMaThuocTinh.setText(kt.getMaKichThuoc());
        txtTenThuocTinh.setText(kt.getTenKichThuoc());
    }

    public void showDataChatLieu(int index) {
        ChatLieu cl = service.getAllCL().get(index);
        txtMaThuocTinh.setText(cl.getMaChatLieu());
        txtTenThuocTinh.setText(cl.getTenChatLieu());
    }

    public void showDataLSP(int index) {
        LoaiSanPham lsp = service.getAllLSP().get(index);
        txtMaThuocTinh.setText(lsp.getMaSP());
        txtTenThuocTinh.setText(lsp.getTenSP());
    }

    MauSac readFormMau() {
        String ma = txtMaThuocTinh.getText();
        String ten = txtTenThuocTinh.getText();
        return new MauSac(WIDTH, ma, ten);
    }

    KichThuoc readFormKT() {
        String ma = txtMaThuocTinh.getText();
        String ten = txtTenThuocTinh.getText();
        return new KichThuoc(WIDTH, ma, ten);
    }

    ChatLieu readFormCL() {
        String ma = txtMaThuocTinh.getText();
        String ten = txtTenThuocTinh.getText();
        return new ChatLieu(WIDTH, ma, ten);
    }

    LoaiSanPham readFormLSP() {
        String ma = txtMaThuocTinh.getText();
        String ten = txtTenThuocTinh.getText();
        return new LoaiSanPham(WIDTH, ma, ten);
    }

    public void clearThuocTinh() {
        txtMaThuocTinh.setText("");
        txtTenThuocTinh.setText("");
    }

    public void clearSanPham() {
        txtMaSP.setText("");
        txtTenSP.setText("");
        cboLoaiSP.setSelectedIndex(0);
        cboKichThuoc.setSelectedIndex(0);
        cboMau.setSelectedIndex(0);
        cboChatLieu.setSelectedIndex(0);
        txtDonGia.setText("");
        txtSoLuong.setText("");
    }

    public boolean checkTrong() {
        if (txtMaThuocTinh.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Mã trống !");
            return false;
        }
        if (txtTenThuocTinh.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Tên trống !");
            return false;
        }
        return true;
    }

    SanPham readFormSP() {
        int ma = Integer.parseInt(txtMaSP.getText());
        String ten = txtTenSP.getText();
        String loai = String.valueOf(cboLoaiSP.getSelectedItem());
        String kt = String.valueOf(cboKichThuoc.getSelectedItem());
        String mau = String.valueOf(cboMau.getSelectedItem());
        String cl = String.valueOf(cboChatLieu.getSelectedItem());
        double gia = Double.valueOf(txtDonGia.getText());
        int sl = Integer.parseInt(txtSoLuong.getText());

        return new SanPham(ma, ten, loai, kt, mau, cl, gia, sl);
    }

    private void showDataSP(int index) {
        SanPham sp = service.getAllSP().get(index);
        tblSanPham.setRowSelectionInterval(index, index);
        txtMaSP.setText(String.valueOf(sp.getStt()));
        txtTenSP.setText(sp.getTen());
        cboLoaiSP.setSelectedItem(sp.getLoai());
        cboKichThuoc.setSelectedItem(sp.getKt());
        cboMau.setSelectedItem(sp.getMs());
        cboChatLieu.setSelectedItem(sp.getCl());
        txtDonGia.setText(String.valueOf(sp.getGia()));
        txtSoLuong.setText(String.valueOf(sp.getSl()));
    }

    private void showDataTimKiemSP(int index) {
        String tim = txtTim.getText();
        SanPham sp = service.timSP(tim).get(index);
        tblSanPham.setRowSelectionInterval(index, index);
        txtMaSP.setText(String.valueOf(sp.getStt()));
        txtTenSP.setText(sp.getTen());
        cboLoaiSP.setSelectedItem(sp.getLoai());
        cboKichThuoc.setSelectedItem(sp.getKt());
        cboMau.setSelectedItem(sp.getMs());
        cboChatLieu.setSelectedItem(sp.getCl());
        txtDonGia.setText(String.valueOf(sp.getGia()));
        txtSoLuong.setText(String.valueOf(sp.getSl()));
    }

    public boolean checkTrongSP() {
        if (txtMaSP.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Mã sản phẩm trống !");
            return false;
        }
        if (txtTenSP.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Tên sản phẩm trống !");
            return false;
        }
        if (txtSoLuong.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Số lượng sản phẩm trống !");
            return false;
        }
        if (txtDonGia.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Đơn giá sản phẩm trống !");
            return false;
        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel16 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        btnThongKe = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnSanPham = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        btnNhanVien = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        btnHoaDon = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        btnKhachHang = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        btnLichSu = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        btnKhuyenMai = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        btnDoiMatKhau = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        btnDangXuat = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jpThongKe = new javax.swing.JPanel();
        jpSanPham = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtTenSP = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        txtDonGia = new javax.swing.JTextField();
        cboKichThuoc = new javax.swing.JComboBox<>();
        cboChatLieu = new javax.swing.JComboBox<>();
        cboMau = new javax.swing.JComboBox<>();
        cboLoaiSP = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnTim = new javax.swing.JButton();
        txtTim = new javax.swing.JTextField();
        btnClear1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        txtTenThuocTinh = new javax.swing.JTextField();
        btnThemTT = new javax.swing.JButton();
        btnSuaTT = new javax.swing.JButton();
        btnXoaTT = new javax.swing.JButton();
        rdoMau = new javax.swing.JRadioButton();
        rdoChatLieu = new javax.swing.JRadioButton();
        rdoKichThuoc = new javax.swing.JRadioButton();
        rdoTenSP = new javax.swing.JRadioButton();
        jLabel25 = new javax.swing.JLabel();
        txtMaThuocTinh = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblThuocTinh = new javax.swing.JTable();
        jpNhanVien = new javax.swing.JPanel();
        jpHoaDon = new javax.swing.JPanel();
        jpKhachHang = new javax.swing.JPanel();
        jpTrangChu = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jpLichSu = new javax.swing.JPanel();
        jpKhuyenMai = new javax.swing.JPanel();
        jpDoiMatKhau = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Alone Wolves");
        setBackground(new java.awt.Color(0, 255, 255));
        setUndecorated(true);

        jPanel16.setBackground(new java.awt.Color(51, 204, 255));
        jPanel16.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(0, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/F5HH_3jaIAAhEJU.jpg"))); // NOI18N
        jLabel1.setText("ALONE WOLVES");

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/2794770.png"))); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        btnThongKe.setForeground(new java.awt.Color(255, 255, 255));
        btnThongKe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnThongKeMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/thong_ke.png"))); // NOI18N
        jLabel2.setText("  Thống kê");

        javax.swing.GroupLayout btnThongKeLayout = new javax.swing.GroupLayout(btnThongKe);
        btnThongKe.setLayout(btnThongKeLayout);
        btnThongKeLayout.setHorizontalGroup(
            btnThongKeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnThongKeLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnThongKeLayout.setVerticalGroup(
            btnThongKeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnThongKeLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        btnSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSanPhamMouseClicked(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/sanpham.png"))); // NOI18N
        jLabel3.setText("  Sản phẩm");

        javax.swing.GroupLayout btnSanPhamLayout = new javax.swing.GroupLayout(btnSanPham);
        btnSanPham.setLayout(btnSanPhamLayout);
        btnSanPhamLayout.setHorizontalGroup(
            btnSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnSanPhamLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnSanPhamLayout.setVerticalGroup(
            btnSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnSanPhamLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        btnNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnNhanVienMouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/nhanvien.png"))); // NOI18N
        jLabel8.setText("  Nhân viên");

        javax.swing.GroupLayout btnNhanVienLayout = new javax.swing.GroupLayout(btnNhanVien);
        btnNhanVien.setLayout(btnNhanVienLayout);
        btnNhanVienLayout.setHorizontalGroup(
            btnNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnNhanVienLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnNhanVienLayout.setVerticalGroup(
            btnNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btnNhanVienLayout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(14, 14, 14))
        );

        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        btnHoaDon.setForeground(new java.awt.Color(0, 0, 0));
        btnHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHoaDonMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/hoadon.png"))); // NOI18N
        jLabel9.setText("  Hóa đơn");

        javax.swing.GroupLayout btnHoaDonLayout = new javax.swing.GroupLayout(btnHoaDon);
        btnHoaDon.setLayout(btnHoaDonLayout);
        btnHoaDonLayout.setHorizontalGroup(
            btnHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnHoaDonLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnHoaDonLayout.setVerticalGroup(
            btnHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnHoaDonLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        btnKhachHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnKhachHangMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/khachhang.png"))); // NOI18N
        jLabel10.setText("  Khách hàng");
        jLabel10.setToolTipText("");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout btnKhachHangLayout = new javax.swing.GroupLayout(btnKhachHang);
        btnKhachHang.setLayout(btnKhachHangLayout);
        btnKhachHangLayout.setHorizontalGroup(
            btnKhachHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnKhachHangLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnKhachHangLayout.setVerticalGroup(
            btnKhachHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btnKhachHangLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(16, 16, 16))
        );

        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        btnLichSu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLichSuMouseClicked(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/lichsu.png"))); // NOI18N
        jLabel11.setText("   Lịch sử");

        javax.swing.GroupLayout btnLichSuLayout = new javax.swing.GroupLayout(btnLichSu);
        btnLichSu.setLayout(btnLichSuLayout);
        btnLichSuLayout.setHorizontalGroup(
            btnLichSuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnLichSuLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnLichSuLayout.setVerticalGroup(
            btnLichSuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnLichSuLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel11)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        btnKhuyenMai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnKhuyenMaiMouseClicked(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/khuyenmai.png"))); // NOI18N
        jLabel12.setText("  Khuyến mãi");

        javax.swing.GroupLayout btnKhuyenMaiLayout = new javax.swing.GroupLayout(btnKhuyenMai);
        btnKhuyenMai.setLayout(btnKhuyenMaiLayout);
        btnKhuyenMaiLayout.setHorizontalGroup(
            btnKhuyenMaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnKhuyenMaiLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );
        btnKhuyenMaiLayout.setVerticalGroup(
            btnKhuyenMaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnKhuyenMaiLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel12)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
        btnDoiMatKhau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnDoiMatKhauMouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/doimatkhau.png"))); // NOI18N
        jLabel13.setText("  Đổi mật khẩu");

        javax.swing.GroupLayout btnDoiMatKhauLayout = new javax.swing.GroupLayout(btnDoiMatKhau);
        btnDoiMatKhau.setLayout(btnDoiMatKhauLayout);
        btnDoiMatKhauLayout.setHorizontalGroup(
            btnDoiMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btnDoiMatKhauLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );
        btnDoiMatKhauLayout.setVerticalGroup(
            btnDoiMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnDoiMatKhauLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel13)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        btnDangXuat.setBackground(new java.awt.Color(51, 204, 255));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgmain/dangxuat.png"))); // NOI18N
        jLabel14.setText("  Đăng xuất");

        javax.swing.GroupLayout btnDangXuatLayout = new javax.swing.GroupLayout(btnDangXuat);
        btnDangXuat.setLayout(btnDangXuatLayout);
        btnDangXuatLayout.setHorizontalGroup(
            btnDangXuatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnDangXuatLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnDangXuatLayout.setVerticalGroup(
            btnDangXuatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btnDangXuatLayout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addContainerGap())
        );

        jpThongKe.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpThongKeLayout = new javax.swing.GroupLayout(jpThongKe);
        jpThongKe.setLayout(jpThongKeLayout);
        jpThongKeLayout.setHorizontalGroup(
            jpThongKeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpThongKeLayout.setVerticalGroup(
            jpThongKeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpSanPham.setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTabbedPane1MousePressed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Quản lý sản phẩm"));

        jLabel16.setText("Mã sản phẩm");

        jLabel17.setText("Tên sản phẩm");

        jLabel18.setText("Số lượng");

        jLabel19.setText("Loại sản phẩm");

        jLabel20.setText("Màu sắc");

        jLabel21.setText("Kích thước");

        jLabel22.setText("Đơn giá");

        jLabel23.setText("Chất liệu");

        cboKichThuoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "S", "L", "XL", "XXL" }));

        cboChatLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cotton", "Nỉ" }));

        cboMau.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Xanh", "Do", "Tim", "Vang" }));

        cboLoaiSP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboLoaiSP, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(113, 113, 113)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboKichThuoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboChatLieu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboMau, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboMau, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cboLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cboKichThuoc, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel6.setName(""); // NOI18N

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã sản phẩm", "Tên sản phẩm", "Loại sản phẩm", "Kích thước", "Màu sắc", "Chất liệu", "Đơn giá", "Số lượng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSanPham);

        btnThem.setBackground(new java.awt.Color(51, 204, 255));
        btnThem.setForeground(new java.awt.Color(255, 255, 255));
        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/them.png"))); // NOI18N
        btnThem.setText("THÊM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setBackground(new java.awt.Color(51, 204, 255));
        btnSua.setForeground(new java.awt.Color(255, 255, 255));
        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/sua.png"))); // NOI18N
        btnSua.setText("SỬA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setBackground(new java.awt.Color(51, 204, 255));
        btnXoa.setForeground(new java.awt.Color(255, 255, 255));
        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/xoa.png"))); // NOI18N
        btnXoa.setText("XÓA");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(51, 204, 255));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/new.png"))); // NOI18N
        btnClear.setText("MỚI");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnTim.setBackground(new java.awt.Color(51, 204, 255));
        btnTim.setForeground(new java.awt.Color(255, 255, 255));
        btnTim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/timkiem.png"))); // NOI18N
        btnTim.setText("TÌM KIẾM");
        btnTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimActionPerformed(evt);
            }
        });

        btnClear1.setBackground(new java.awt.Color(51, 204, 255));
        btnClear1.setForeground(new java.awt.Color(255, 255, 255));
        btnClear1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/load.png"))); // NOI18N
        btnClear1.setText("LOAD TABLE");
        btnClear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClear1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addGap(18, 18, 18)
                        .addComponent(btnSua)
                        .addGap(18, 18, 18)
                        .addComponent(btnXoa)
                        .addGap(18, 18, 18)
                        .addComponent(btnClear)
                        .addGap(18, 18, 18)
                        .addComponent(btnClear1)
                        .addGap(18, 18, 18)
                        .addComponent(btnTim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTim)
                    .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnClear)
                    .addComponent(btnClear1))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thông tin sản phẩm", jPanel4);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel24.setText("Tên thuộc tính");

        btnThemTT.setBackground(new java.awt.Color(51, 204, 255));
        btnThemTT.setForeground(new java.awt.Color(255, 255, 255));
        btnThemTT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/them.png"))); // NOI18N
        btnThemTT.setText("THÊM");
        btnThemTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemTTActionPerformed(evt);
            }
        });

        btnSuaTT.setBackground(new java.awt.Color(51, 204, 255));
        btnSuaTT.setForeground(new java.awt.Color(255, 255, 255));
        btnSuaTT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/sua.png"))); // NOI18N
        btnSuaTT.setText("SỬA");
        btnSuaTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaTTActionPerformed(evt);
            }
        });

        btnXoaTT.setBackground(new java.awt.Color(51, 204, 255));
        btnXoaTT.setForeground(new java.awt.Color(255, 255, 255));
        btnXoaTT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/xoa.png"))); // NOI18N
        btnXoaTT.setText("XÓA");
        btnXoaTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaTTActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdoMau);
        rdoMau.setText("Màu sắc");
        rdoMau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdoMauMouseClicked(evt);
            }
        });

        buttonGroup1.add(rdoChatLieu);
        rdoChatLieu.setText("Chất liệu");
        rdoChatLieu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdoChatLieuMouseClicked(evt);
            }
        });

        buttonGroup1.add(rdoKichThuoc);
        rdoKichThuoc.setText("Kích thước");
        rdoKichThuoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdoKichThuocMouseClicked(evt);
            }
        });

        buttonGroup1.add(rdoTenSP);
        rdoTenSP.setText("Loại sản phẩm");
        rdoTenSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdoTenSPMouseClicked(evt);
            }
        });

        jLabel25.setText("Mã thuộc tính");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnThemTT)
                        .addGap(18, 18, 18)
                        .addComponent(btnSuaTT)
                        .addGap(18, 18, 18)
                        .addComponent(btnXoaTT))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtMaThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTenThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(63, 63, 63)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(rdoMau)
                        .addGap(18, 18, 18)
                        .addComponent(rdoChatLieu))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(rdoKichThuoc)
                        .addGap(18, 18, 18)
                        .addComponent(rdoTenSP)))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdoMau)
                            .addComponent(rdoChatLieu)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMaThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtTenThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rdoKichThuoc)
                        .addComponent(rdoTenSP))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnThemTT)
                            .addComponent(btnSuaTT)
                            .addComponent(btnXoaTT))))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        tblThuocTinh.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "STT", "Loại Thuộc Tính", "Mã Thuộc Tính", "Tên Thuộc Tính"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblThuocTinh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblThuocTinhMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblThuocTinh);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(154, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thuộc tính sản phẩm", jPanel2);

        javax.swing.GroupLayout jpSanPhamLayout = new javax.swing.GroupLayout(jpSanPham);
        jpSanPham.setLayout(jpSanPhamLayout);
        jpSanPhamLayout.setHorizontalGroup(
            jpSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSanPhamLayout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 825, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 75, Short.MAX_VALUE))
        );
        jpSanPhamLayout.setVerticalGroup(
            jpSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSanPhamLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        jpNhanVien.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpNhanVienLayout = new javax.swing.GroupLayout(jpNhanVien);
        jpNhanVien.setLayout(jpNhanVienLayout);
        jpNhanVienLayout.setHorizontalGroup(
            jpNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpNhanVienLayout.setVerticalGroup(
            jpNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpHoaDon.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpHoaDonLayout = new javax.swing.GroupLayout(jpHoaDon);
        jpHoaDon.setLayout(jpHoaDonLayout);
        jpHoaDonLayout.setHorizontalGroup(
            jpHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpHoaDonLayout.setVerticalGroup(
            jpHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpKhachHang.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpKhachHangLayout = new javax.swing.GroupLayout(jpKhachHang);
        jpKhachHang.setLayout(jpKhachHangLayout);
        jpKhachHangLayout.setHorizontalGroup(
            jpKhachHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpKhachHangLayout.setVerticalGroup(
            jpKhachHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpTrangChu.setBackground(new java.awt.Color(255, 255, 255));

        jLabel15.setFont(new java.awt.Font("Snap ITC", 0, 48)); // NOI18N
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FsuXC31XoAMORaK.jpg"))); // NOI18N
        jLabel15.setText("   Trang chu");

        javax.swing.GroupLayout jpTrangChuLayout = new javax.swing.GroupLayout(jpTrangChu);
        jpTrangChu.setLayout(jpTrangChuLayout);
        jpTrangChuLayout.setHorizontalGroup(
            jpTrangChuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpTrangChuLayout.createSequentialGroup()
                .addGap(298, 298, 298)
                .addComponent(jLabel15)
                .addContainerGap(49, Short.MAX_VALUE))
        );
        jpTrangChuLayout.setVerticalGroup(
            jpTrangChuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpTrangChuLayout.createSequentialGroup()
                .addGap(222, 222, 222)
                .addComponent(jLabel15)
                .addContainerGap(165, Short.MAX_VALUE))
        );

        jpLichSu.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpLichSuLayout = new javax.swing.GroupLayout(jpLichSu);
        jpLichSu.setLayout(jpLichSuLayout);
        jpLichSuLayout.setHorizontalGroup(
            jpLichSuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpLichSuLayout.setVerticalGroup(
            jpLichSuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpKhuyenMai.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpKhuyenMaiLayout = new javax.swing.GroupLayout(jpKhuyenMai);
        jpKhuyenMai.setLayout(jpKhuyenMaiLayout);
        jpKhuyenMaiLayout.setHorizontalGroup(
            jpKhuyenMaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpKhuyenMaiLayout.setVerticalGroup(
            jpKhuyenMaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        jpDoiMatKhau.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jpDoiMatKhauLayout = new javax.swing.GroupLayout(jpDoiMatKhau);
        jpDoiMatKhau.setLayout(jpDoiMatKhauLayout);
        jpDoiMatKhauLayout.setHorizontalGroup(
            jpDoiMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpDoiMatKhauLayout.setVerticalGroup(
            jpDoiMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpDoiMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpKhuyenMai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpLichSu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpTrangChu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpDoiMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpKhuyenMai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpLichSu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jpSanPham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jpTrangChu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton10)
                .addContainerGap())
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNhanVien, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLichSu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnKhuyenMai, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDoiMatKhau, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDangXuat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnKhachHang, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnHoaDon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSanPham, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton10)))
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLichSu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnKhuyenMai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDoiMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDangXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn thoát ?", "Thoát", 2);
        if (chon == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else {
            return;
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        index = tblSanPham.getSelectedRow();
        showDataSP(index);
        showDataTimKiemSP(index);
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        if (checkTrongSP()) {
            SanPham sp = readFormSP();
            if (service.getMaSP(String.valueOf(sp.getStt())) == null) {
                if (service.addSP(sp) > 0) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công !");
                    fillToTableSanPham(service.getAllSP());
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại !");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Mã trùng !");
            }
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        if (checkTrongSP()) {
            SanPham sp = readFormSP();
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn sửa sản phẩm này ?");
            if (chon == JOptionPane.YES_OPTION) {
                if (service.updateSP(sp, String.valueOf(sp.getStt())) > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công !");
                    fillToTableSanPham(service.getAllSP());
                    tblSanPham.setRowSelectionInterval(index, index);
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa thất bại !");
                }
            } else {
                return;
            }
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        if (checkTrongSP()) {
            SanPham sp = readFormSP();
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa sản phẩm này ?");
            if (chon == JOptionPane.YES_OPTION) {
                if (service.deleteSP(String.valueOf(sp.getStt())) > 0) {
                    JOptionPane.showMessageDialog(this, "Xóa thành công !");
                    fillToTableSanPham(service.getAllSP());
                    clearSanPham();
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa thất bại !");
                }
            } else {
                return;
            }
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        this.clearSanPham();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimActionPerformed
        String timKiem = txtTim.getText().trim();
        if (timKiem.equalsIgnoreCase("")) {
            fillToTableSanPham(service.getAllSP());
        } else if (service.timSP(timKiem) != null) {
            fillToTableSanPham(service.timSP(timKiem));
            index = 0;
            tblSanPham.setRowSelectionInterval(index, index);
            showDataTimKiemSP(index);
        }
    }//GEN-LAST:event_btnTimActionPerformed

    private void btnClear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClear1ActionPerformed
        fillToTableSanPham(service.getAllSP());
        this.clearThuocTinh();
    }//GEN-LAST:event_btnClear1ActionPerformed

    private void btnThemTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemTTActionPerformed
        if (rdoMau.isSelected()) {
            MauSac ms = readFormMau();
            if (checkTrong()) {
                if (service.getMaMau(ms.getMaMau()) == null) {
                    if (service.getMau(ms.getTenMau()) == null) {
                        if (service.addMau(ms) > 0) {
                            JOptionPane.showMessageDialog(this, "Thêm thành công !");
                            fillToTableMau(service.getAllMau());
                            fillCbo();
                        } else {
                            JOptionPane.showMessageDialog(this, "Thêm thất bại !");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Đã có màu !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Trùng mã !");
                }
            }
        } else if (rdoKichThuoc.isSelected()) {
            KichThuoc kt = readFormKT();
            if (checkTrong()) {
                if (service.getMaKT(kt.getMaKichThuoc()) == null) {
                    if (service.getKT(kt.getTenKichThuoc()) == null) {
                        if (service.addKichThuoc(kt) > 0) {
                            JOptionPane.showMessageDialog(this, "Thêm thành công !");
                            fillToTableKichThuoc(service.getAllKT());
                            fillCbo();
                        } else {
                            JOptionPane.showMessageDialog(this, "Thêm thất bại !");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Đã có kích thước !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Trùng mã !");
                }
            }
        } else if (rdoChatLieu.isSelected()) {
            ChatLieu cl = readFormCL();
            if (checkTrong()) {
                if (service.getMaCL(cl.getMaChatLieu()) == null) {
                    if (service.getCL(cl.getMaChatLieu()) == null) {
                        if (service.addChatLieu(cl) > 0) {
                            JOptionPane.showMessageDialog(this, "Thêm thành công !");
                            fillToTableChatLieu(service.getAllCL());
                            fillCbo();
                        } else {
                            JOptionPane.showMessageDialog(this, "Thêm thất bại !");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Đã có chất liệu !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Trùng mã !");
                }
            }
        } else if (rdoTenSP.isSelected()) {
            LoaiSanPham lsp = readFormLSP();
            if (checkTrong()) {
                if (service.getMaLSP(lsp.getMaSP()) == null) {
                    if (service.getLSP(lsp.getTenSP()) == null) {
                        if (service.addLoaiSP(lsp) > 0) {
                            JOptionPane.showMessageDialog(this, "Thêm thành công !");
                            fillToTableLoaiSP(service.getAllLSP());
                            fillCbo();
                        } else {
                            JOptionPane.showMessageDialog(this, "Thêm thất bại !");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Đã có loại sản phẩm !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Trùng mã !");
                }
            }
        }
    }//GEN-LAST:event_btnThemTTActionPerformed

    private void btnSuaTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaTTActionPerformed
        if (rdoMau.isSelected()) {
            MauSac ms = readFormMau();
            if (checkTrong()) {
                if (service.getMau(ms.getTenMau()) == null) {
                    if (service.updateMau(ms, ms.getMaMau()) > 0) {
                        JOptionPane.showMessageDialog(this, "Update thành công !");
                        fillToTableMau(service.getAllMau());
                        fillCbo();
                    } else {
                        JOptionPane.showMessageDialog(this, "Update thất bại !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Đã có màu !");
                }
            }
        } else if (rdoKichThuoc.isSelected()) {
            KichThuoc kt = readFormKT();
            if (checkTrong()) {
                if (service.getKT(kt.getTenKichThuoc()) == null) {
                    if (service.updateKichThuoc(kt, kt.getMaKichThuoc()) > 0) {
                        JOptionPane.showMessageDialog(this, "Update thành công !");
                        fillToTableKichThuoc(service.getAllKT());
                        fillCbo();
                    } else {
                        JOptionPane.showMessageDialog(this, "Update thất bại !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Đã có kích thước !");
                }
            }
        } else if (rdoChatLieu.isSelected()) {
            ChatLieu cl = readFormCL();
            if (checkTrong()) {
                if (service.getCL(cl.getMaChatLieu()) == null) {
                    if (service.updateChatLieu(cl, cl.getMaChatLieu()) > 0) {
                        JOptionPane.showMessageDialog(this, "Update thành công !");
                        fillToTableChatLieu(service.getAllCL());
                        fillCbo();
                    } else {
                        JOptionPane.showMessageDialog(this, "Update thất bại !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Đã có chất liệu !");
                }
            }
        } else if (rdoTenSP.isSelected()) {
            LoaiSanPham lsp = readFormLSP();
            if (checkTrong()) {
                if (service.getLSP(lsp.getTenSP()) == null) {
                    if (service.updateLoaiSP(lsp, lsp.getMaSP()) > 0) {
                        JOptionPane.showMessageDialog(this, "Update thành công !");
                        fillToTableLoaiSP(service.getAllLSP());
                        fillCbo();
                    } else {
                        JOptionPane.showMessageDialog(this, "Update thất bại !");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Đã có loại sản phẩm !");
                }
            }
        }
    }//GEN-LAST:event_btnSuaTTActionPerformed

    private void btnXoaTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaTTActionPerformed
        if (rdoMau.isSelected()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa màu này ?");
            if (chon == JOptionPane.YES_OPTION) {
                MauSac ms = readFormMau();
                if (ms.getMaMau().equals("")) {
                    JOptionPane.showMessageDialog(this, "Mã trống !");
                } else {
                    if (service.deleteMau(ms.getMaMau()) > 0) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công !");
                        fillToTableMau(service.getAllMau());
                        fillCbo();
                        this.clearThuocTinh();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại !");
                    }
                }
            } else {
                return;
            }
        } else if (rdoKichThuoc.isSelected()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa kích thước này ?");
            if (chon == JOptionPane.YES_OPTION) {
                KichThuoc kt = readFormKT();
                if (kt.getMaKichThuoc().equals("")) {
                    JOptionPane.showMessageDialog(this, "Mã trống !");
                } else {
                    if (service.deleteMau(kt.getMaKichThuoc()) > 0) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công !");
                        fillToTableKichThuoc(service.getAllKT());
                        fillCbo();
                        this.clearThuocTinh();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại !");
                    }
                }
            } else {
                return;
            }
        } else if (rdoChatLieu.isSelected()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa chất liệu này ?");
            if (chon == JOptionPane.YES_OPTION) {
                ChatLieu cl = readFormCL();
                if (cl.getMaChatLieu().equals("")) {
                    JOptionPane.showMessageDialog(this, "Mã trống !");
                } else {
                    if (service.deleteCL(cl.getMaChatLieu()) > 0) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công !");
                        fillToTableChatLieu(service.getAllCL());
                        fillCbo();
                        this.clearThuocTinh();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại !");
                    }
                }
            } else {
                return;
            }
        } else if (rdoTenSP.isSelected()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa loại này ?");
            if (chon == JOptionPane.YES_OPTION) {
                LoaiSanPham lsp = readFormLSP();
                if (lsp.getMaSP().equals("")) {
                    JOptionPane.showMessageDialog(this, "Mã trống !");
                } else {
                    if (service.deleteLSP(lsp.getMaSP()) > 0) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công !");
                        fillToTableLoaiSP(service.getAllLSP());
                        fillCbo();
                        this.clearThuocTinh();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại !");
                    }
                }
            } else {
                return;
            }
        }
    }//GEN-LAST:event_btnXoaTTActionPerformed

    private void rdoMauMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdoMauMouseClicked
        if (rdoMau.isSelected()) {
            fillToTableMau(service.getAllMau());
        }
    }//GEN-LAST:event_rdoMauMouseClicked

    private void rdoChatLieuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdoChatLieuMouseClicked
        if (rdoChatLieu.isSelected()) {
            fillToTableChatLieu(service.getAllCL());
        }
    }//GEN-LAST:event_rdoChatLieuMouseClicked

    private void rdoKichThuocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdoKichThuocMouseClicked
        if (rdoKichThuoc.isSelected()) {
            fillToTableKichThuoc(service.getAllKT());
        }
    }//GEN-LAST:event_rdoKichThuocMouseClicked

    private void rdoTenSPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdoTenSPMouseClicked
        if (rdoTenSP.isSelected()) {
            fillToTableLoaiSP(service.getAllLSP());
        }
    }//GEN-LAST:event_rdoTenSPMouseClicked

    private void tblThuocTinhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblThuocTinhMouseClicked
        index = tblThuocTinh.getSelectedRow();
        if (rdoMau.isSelected()) {
            showDataMau(index);
        } else if (rdoKichThuoc.isSelected()) {
            showDataKichThuoc(index);
        } else if (rdoChatLieu.isSelected()) {
            showDataChatLieu(index);
        } else if (rdoTenSP.isSelected()) {
            showDataLSP(index);
        }
    }//GEN-LAST:event_tblThuocTinhMouseClicked

    private void jTabbedPane1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MousePressed
        fillToTableSanPham(service.getAllSP());
        this.clearThuocTinh();
    }//GEN-LAST:event_jTabbedPane1MousePressed

    private void btnThongKeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnThongKeMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(true);
        btnThongKe.setBackground(Color.cyan);
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnThongKeMouseClicked

    private void btnSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSanPhamMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(true);
        btnSanPham.setBackground(Color.CYAN);
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnSanPhamMouseClicked

    private void btnNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnNhanVienMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(true);
        btnNhanVien.setBackground(Color.CYAN);
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnNhanVienMouseClicked

    private void btnHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHoaDonMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(true);
        btnHoaDon.setBackground(Color.CYAN);
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnHoaDonMouseClicked

    private void btnLichSuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLichSuMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(true);
        btnLichSu.setBackground(Color.CYAN);
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnLichSuMouseClicked

    private void btnKhuyenMaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnKhuyenMaiMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(true);
        btnKhuyenMai.setBackground(Color.CYAN);
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnKhuyenMaiMouseClicked

    private void btnDoiMatKhauMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDoiMatKhauMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(false);
        btnKhachHang.setBackground(new java.awt.Color(51, 204, 255));
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(true);
        btnDoiMatKhau.setBackground(Color.CYAN);
    }//GEN-LAST:event_btnDoiMatKhauMouseClicked

    private void btnKhachHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnKhachHangMouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(true);
        btnKhachHang.setBackground(Color.CYAN);
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_btnKhachHangMouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        jpTrangChu.setVisible(false);
        jpThongKe.setVisible(false);
        btnThongKe.setBackground(new java.awt.Color(51, 204, 255));
        jpSanPham.setVisible(false);
        btnSanPham.setBackground(new java.awt.Color(51, 204, 255));
        jpNhanVien.setVisible(false);
        btnNhanVien.setBackground(new java.awt.Color(51, 204, 255));
        jpHoaDon.setVisible(false);
        btnHoaDon.setBackground(new java.awt.Color(51, 204, 255));
        jpKhachHang.setVisible(true);
        btnKhachHang.setBackground(Color.CYAN);
        jpLichSu.setVisible(false);
        btnLichSu.setBackground(new java.awt.Color(51, 204, 255));
        jpKhuyenMai.setVisible(false);
        btnKhuyenMai.setBackground(new java.awt.Color(51, 204, 255));
        jpDoiMatKhau.setVisible(false);
        btnDoiMatKhau.setBackground(new java.awt.Color(51, 204, 255));
    }//GEN-LAST:event_jLabel10MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QuanLySanPham().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnClear1;
    private javax.swing.JPanel btnDangXuat;
    private javax.swing.JPanel btnDoiMatKhau;
    private javax.swing.JPanel btnHoaDon;
    private javax.swing.JPanel btnKhachHang;
    private javax.swing.JPanel btnKhuyenMai;
    private javax.swing.JPanel btnLichSu;
    private javax.swing.JPanel btnNhanVien;
    private javax.swing.JPanel btnSanPham;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnSuaTT;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnThemTT;
    private javax.swing.JPanel btnThongKe;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton btnXoaTT;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboChatLieu;
    private javax.swing.JComboBox<String> cboKichThuoc;
    private javax.swing.JComboBox<String> cboLoaiSP;
    private javax.swing.JComboBox<String> cboMau;
    private javax.swing.JButton jButton10;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel jpDoiMatKhau;
    private javax.swing.JPanel jpHoaDon;
    private javax.swing.JPanel jpKhachHang;
    private javax.swing.JPanel jpKhuyenMai;
    private javax.swing.JPanel jpLichSu;
    private javax.swing.JPanel jpNhanVien;
    private javax.swing.JPanel jpSanPham;
    private javax.swing.JPanel jpThongKe;
    private javax.swing.JPanel jpTrangChu;
    private javax.swing.JRadioButton rdoChatLieu;
    private javax.swing.JRadioButton rdoKichThuoc;
    private javax.swing.JRadioButton rdoMau;
    private javax.swing.JRadioButton rdoTenSP;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTable tblThuocTinh;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextField txtMaThuocTinh;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSP;
    private javax.swing.JTextField txtTenThuocTinh;
    private javax.swing.JTextField txtTim;
    // End of variables declaration//GEN-END:variables

}
